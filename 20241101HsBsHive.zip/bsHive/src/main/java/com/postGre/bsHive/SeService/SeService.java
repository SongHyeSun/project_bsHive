package com.postGre.bsHive.SeService;


public interface SeService {
	








}
