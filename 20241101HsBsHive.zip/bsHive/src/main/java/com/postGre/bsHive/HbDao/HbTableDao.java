package com.postGre.bsHive.HbDao;

public interface HbTableDao {

}
