package com.postGre.bsHive.MnService;

import java.util.List;

import com.postGre.bsHive.Amodel.Crans_Qitem;


public interface MnService {

	List<Crans_Qitem> selAll();

}
