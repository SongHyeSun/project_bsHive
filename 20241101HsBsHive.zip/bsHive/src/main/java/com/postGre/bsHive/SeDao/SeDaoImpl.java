 package com.postGre.bsHive.SeDao;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class SeDaoImpl implements SeDao {
	
	

}
