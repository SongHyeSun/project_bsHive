package com.postGre.bsHive.JwDao;

import java.util.List;

import com.postGre.bsHive.Adto.All_Lctr;

public interface JwDao {

	List<All_Lctr> 			listAllLctr(All_Lctr al);

}
