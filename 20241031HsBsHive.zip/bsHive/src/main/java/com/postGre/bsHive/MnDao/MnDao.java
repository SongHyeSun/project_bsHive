package com.postGre.bsHive.MnDao;

import java.util.List;

import com.postGre.bsHive.Amodel.Crans_Qitem;



public interface MnDao {

	List<Crans_Qitem> selAll();
	
}
