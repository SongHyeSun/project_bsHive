package com.postGre.bsHive.SeDao;


public interface SeDao {








	
}
