package com.postGre.bsHive.HbService;

public interface HbTableService {

	void addCourseEval();

}
