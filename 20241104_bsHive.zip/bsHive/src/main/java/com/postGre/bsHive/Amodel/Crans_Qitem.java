package com.postGre.bsHive.Amodel;

import lombok.Data;

//정답문항 TBL

@Data
public class Crans_Qitem {
	private String 	crans_no; 	 //정답코드
	private String 	qitem_no; 	 //문항번호
	private String 	cycl; 		 //차수
	private int		lctr_num; 	 //강의번호
	private String  qitem_expln; //객관식보기
	private String 	crans_yn; 	 //정답여부
	private String 	crans_sbj; 	 //주관식답안

}
