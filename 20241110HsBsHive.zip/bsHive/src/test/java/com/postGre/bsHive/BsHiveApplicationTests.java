package com.postGre.bsHive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsHiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
